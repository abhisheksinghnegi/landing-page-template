
const Footer = () => {
    return (
        <div>
            <footer style={{border:"1px solid black", marginTop: "20px", padding:"20px", textAlign:"center"}}>This is a footer</footer>
        </div>
    )
}

export default Footer
