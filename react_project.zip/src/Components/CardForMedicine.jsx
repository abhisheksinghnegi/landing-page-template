import React, { useState } from "react";
import './CardForMedicine.css'
import cart from '../images/cart.webp'
import ReactModal from 'react-modal';
import { show } from "react-modal/lib/helpers/ariaAppHider";

const CardForMedicine = (props) => {

    const [showModal, setShowModal] = useState(false)
    console.log("showModal ", showModal)
    const handleOpenModal = () => {
        setShowModal(true);
    }

    const handleCloseModal = () => {
        setShowModal(false);
    }
    return (
        <div >
            {/* <button onClick={handleOpenModal}>Trigger Modal</button> */}
            <div class="container-fluid " onClick={handleOpenModal}>
                <div class="row">
                    <div class="col-12 mt-3">
                        <div class="card">
                            <div class="card-horizontal">
                                <div class="img-square-wrapper">
                                    <img className="" style={{ height: "200px", width: "200px" }} src={cart} alt="Card image cap" />
                                </div>
                                {/* id={value.id} drugName={value.drugName} drugMg={value.drugMg} cost={value.cost} */}
                                <div class="card-body">
                                    <h4 class="card-title"> {props.values.drugName} </h4>
                                    <p>{props.values.drugMg + " mg"} </p>

                                    <p>{props.values.quantityperPack} per Pack</p>
                                    <p class="card-text">₹{"  " + props.values.cost}</p>
                                </div>
                            </div>
                            <div class="card-footer">
                                <small class="text-muted">ID - {props.values.id}</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* <button onClick={this.handleOpenModal}>Trigger Modal</button> */}
            <ReactModal
                isOpen={showModal}
                contentLabel="onRequestClose Example"
                onRequestClose={handleCloseModal}
                ariaHideApp={false}
            >
                <nav className="nav" >
                    <p className="btn btn-outline-primary" onClick={handleCloseModal}>Back to all Medicines</p>
                </nav>
                <div className="row">
                    <div class="photo col-lg-6">
                        <img style={{ width: "50%", height: "50%", padding: "25px", marginBottom: "20px", marginLeft: "50px" }} src="https://s-media-cache-ak0.pinimg.com/236x/3b/36/ca/3b36ca3afe0fa0fd4984b9eee2e154bb.jpg" />
                         </div>
                    <div class="description col-lg-6">
                        <h3>{props.values.id} </h3>
                        <h1 style={{ display: "inline" }}>{props.values.drugName + "  "}</h1><span >({props.values.drugMg}mg)</span>
                        <br/>
                        <div>
                            <h3 style={{ display: "inline" }} >$ {props.values.cost}</h3><span >(inc. tax)</span></div>
                        <p>Paracetamol is used for pain relief and fever. It is used to relieve pain in conditions like headache, muscle pain, or dental pain.</p>
                        <button className="btn btn-warning" style={{ marginRight: "100px", marginLeft: "50px", fontWeight: "bold", display: "inline" }}>Add to Cart</button>
                        <button className="btn btn-warning" style={{ marginLeft: "5px", fontWeight: "bold", display: "inline" }}>Buy Now</button>
                   
                    </div>
                </div>
            </ReactModal>
            {/* private int id;
	
	private String drugName;
	private String drugMg;
	private int cost;
	private int QuantityperPack;
	private String Manufacturer;
	private String MaufacturerDate;
	private String ExpiryDate; */}
        </div >
    )
}

export default CardForMedicine;