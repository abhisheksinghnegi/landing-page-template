import Navbar from './Navbar'

const Header = () => {

    return (
        <div>
            <header>
            <Navbar/>
            </header>
        </div>
    )
}

export default Header
