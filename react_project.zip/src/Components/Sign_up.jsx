import React, { useState } from "react";
import swal from 'sweetalert';
import { useAuth0 } from "@auth0/auth0-react";
import Profile from "./Profile"

const Contact = () => {
  const [users, setUsers] = useState([
    {
      id: 1,
      firstName: 'Frank',
      lastName: 'Murphy',
      email: 'frank.murphy@test.com',
      role: 'User',
    },
    {
      id: 2,
      firstName: 'Vic',
      lastName: 'Reynolds',
      email: 'vic.reynolds@test.com',
      role: 'Admin',
    },
    {
      id: 3,
      firstName: 'Gina',
      lastName: 'Jabowski',
      email: 'gina.jabowski@test.com',
      role: 'Admin',
    },
    {
      id: 4,
      firstName: 'Jessi',
      lastName: 'Glaser',
      email: 'jessi.glaser@test.com',
      role: 'User',
    },
    {
      id: 5,
      firstName: 'Jay',
      lastName: 'Bilzerian',
      email: 'jay.bilzerian@test.com',
      role: 'User',
    },
    {
      id: 1,
      firstName: 'Frank',
      lastName: 'Murphy',
      email: 'frank.murphy@test.com',
      role: 'User',
    },
    {
      id: 2,
      firstName: 'Vic',
      lastName: 'Reynolds',
      email: 'vic.reynolds@test.com',
      role: 'Admin',
    },
    {
      id: 3,
      firstName: 'Gina',
      lastName: 'Jabowski',
      email: 'gina.jabowski@test.com',
      role: 'Admin',
    },
    {
      id: 3,
      firstName: 'Gina',
      lastName: 'Jabowski',
      email: 'gina.jabowski@test.com',
      role: 'Admin',
    },
    {
      id: 4,
      firstName: 'Jessi',
      lastName: 'Glaser',
      email: 'jessi.glaser@test.com',
      role: 'User',
    },
    {
      id: 5,
      firstName: 'Jay',
      lastName: 'Bilzerian',
      email: 'jay.bilzerian@test.com',
      role: 'User',
    },
  ]);
  const {loginWithRedirect, user, logout} = useAuth0();
  const logData = ()=>{
    {JSON.stringify(user,null,2)}
  }
  return (
    <div>
      You are not logged in
    {/* <button onClick={() => loginWithRedirect()}> Log In </button>
    <Profile/>
    <button onClick={() => logout()}>Log Out</button>

    <CardComponent/> */}
    <div className="container">
      <h3 className="p-3 text-center">React - Display a list of items</h3>
      <table className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          {users &&
            users.map((user) => (
              <tr key={user.id}>
                <td>
                  {user.firstName} {user.lastName}
                </td>
                <td>{user.email}</td>
                <td>{user.role}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
     </div>
  );
};

export default Contact;
