import React from 'react';
import home from "../images/home.svg";
import Common from './Common';
import Profile from './Profile';
import Button from './Button'
import Counter from './Counter';
import Modal from './Modal';
const Home = () => {
    return (
        <>
            <Common 
                name='Fulfill your medicine need with' 
                imgsrc={home} 
                isCompName={true}
                compName="Medical Shop"
                visit='/services' 
                btnname="Get Started"
                message="We are there for you. Through whatever, whenever."
                userName="User"
            />
            <Profile/>
           <Modal/>
        </>
    )
}

export default Home;